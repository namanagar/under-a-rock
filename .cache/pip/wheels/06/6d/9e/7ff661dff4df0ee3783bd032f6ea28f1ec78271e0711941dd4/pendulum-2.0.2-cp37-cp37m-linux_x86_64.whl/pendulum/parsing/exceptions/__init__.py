
class ParserError(ValueError):

    pass
