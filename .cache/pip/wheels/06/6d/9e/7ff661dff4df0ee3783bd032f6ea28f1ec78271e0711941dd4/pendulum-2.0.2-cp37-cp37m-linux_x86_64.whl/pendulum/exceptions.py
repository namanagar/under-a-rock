from .parsing.exceptions import ParserError


class PendulumException(Exception):

    pass
